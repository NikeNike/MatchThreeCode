//
//  Grid.h
//  MatchThree
//
//  Created by Dimitar Dimitrov on 5/2/16.
//
//

#ifndef MATCH_THREE_GRID_H
#define MATCH_THREE_GRID_H

#include <cocos2d.h>
#include "Block.h"

class Grid: public cocos2d::Layer
{
public:
    
    static Grid* createGrid(int rows, int cols);   // Create Grid With Rows and Cols
    Block* blocks[MAX_ROWS][MAX_COLS];
    
    
    void generateRandomBlocks();

};

#endif /* _MATCH_THREE_GRID_H_ */
