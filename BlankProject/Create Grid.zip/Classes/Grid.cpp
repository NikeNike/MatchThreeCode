//
//  Grid.cpp
//  MatchThree
//
//  Created by Dimitar Dimitrov on 5/2/16.
//
//

#include "Grid.h"
#include "SimpleAudioEngine.h"
#include "Global.h"

USING_NS_CC;

Grid* Grid::createGrid(int rows, int cols)
{
    Grid* grid = new (std::nothrow) Grid();
    
    if (grid && grid->init())
    {
        grid->autorelease();
        grid->setContentSize(Size(rows * _BlockSize.width, cols * _BlockSize.height));
        grid->setAnchorPoint(Vec2::ANCHOR_MIDDLE);
        return grid;
    }
    else
    {
        CC_SAFE_DELETE(grid);
    }
   
    
    return nullptr;
};

void Grid::generateRandomBlocks()
{
    for (int col = 0; col < MAX_COLS; col++)
    {
        for (int row = 0; row < MAX_ROWS; row++)
        {
            Block* block = Block::createBlock((BlockType)random((int)BlockType::RED, (int)BlockType::PINK), {row, col});
            
            // Make sure there are no initial groups of matches
//            while(checkForMatches(block) == true)
//            {
//                block->setType((BlockType)random((int)BlockType::RED, (int)BlockType::PINK));
//            }
            
            block->setPosition(row * _BlockSize.width + _BlockSize.width * 0.5f,
                               col * _BlockSize.height + _BlockSize.height * 0.5f);
            
            addChild(block, 1);
            blocks[row][col] = block;
        }
    }
}

