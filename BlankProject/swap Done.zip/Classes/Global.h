//
//  Global.h
//  MatchThree
//
//  Created by Dimitar Dimitrov on 5/2/16.
//
//

#ifndef __MATCH_THREE_APP_GLOBAL_H_
#define __MATCH_THREE_APP_GLOBAL_H_

#include <cocos2d.h>


const cocos2d::Size _BlockSize = cocos2d::Size(80, 80);
// Size of the grid
const int MAX_ROWS = 8;
const int MAX_COLS = 8;
const int SWIPE_TRESHOLD = 5; // Minimum pixels for swipe move

const int MAX_MATCHES = 3;

enum class BlockType : int
{
    RED = 0,
    YELLOW,
    PINK

};
const char* const BlockTypeToFrameName[]
{
    "red.png",        // RED,
    "yellow.png",    // YELLOW
    "pink.png"    // PURPLE
};
    
    


struct GridPosition {
    /** Row index in the grid */
    int row;
    /** Column index in the grid */
    int col;
};


#endif /* __MATCH_THREE_APP_GLOBAL_H_ */
